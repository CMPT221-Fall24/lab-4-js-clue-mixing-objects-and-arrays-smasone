let suspectsArray = ["Mister Maroon", "Madame Magenta", "Lady Lily", "Baron Burgundy", "Dame Dawn", "Sir Saffron"]
let weaponsArray = ["lamp", "poison", "chisel", "spear", "statue", "icicle", "bottle", "bomb"]
let roomsArray = ["studio", "courtroom", "prison", "kitchen", "restaurant", "beachhouse", "circus", "office", "spaceship", "school"]

function selectRandom(randArray) {
    let temp = Math.floor(Math.random() * randArray.length)
    return randArray[temp]
}

function pickMystery() {
    mystery = new Object();
    mystery.suspect = selectRandom(suspectsArray)
    mystery.weapon = selectRandom(weaponsArray)
    mystery.room = selectRandom(roomsArray)
    return mystery
}

function revealMystery(mystery) {
    document.getElementById("Reveal").innerText="It was " + mystery.suspect + " in the " + mystery.room + " with the " + mystery.weapon + "!"
}